<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf8">
        <title>Vos équipements</title>
        <?php 
            $JSON = file_get_contents("Data.json");
            $JSON = json_decode($JSON, true);
            $traitement = $JSON[0]['fichierTraitement'];
            $resultatCSS = $JSON[0]['fichierResultatCSS'];
            include($traitement);
        ?>
        <link rel="stylesheet" href=<?php echo $resultatCSS?>>
    </head>
    
    <body>
        <nav>
            <a href="https://www.toutatice.fr/portail/">
            <img src="img/toutatice.jpg" alt="toutatice.fr, espace numérique de l'éducation en Bretagne">
            </a>
            <p1>Mon Compte</p1>
            <p2><a href=<?php echo $fichierBase?>><?php echo($nom_ID) ?></a></p2>
        </nav>
        <div class="divPrincipale">
            <div class="menu_monCompte">
                <p><img src="img/utilisateur-24.png">Information personnelles</p>
                <p><img src="img/téléphone-24.png">Numéro de téléphone</p>
                <p><img src="img/pouces-levé-baissé-50.png">Registre de consentement</p>
                <p><img src="img/ordinateur-portable-24.png">Mes équipement</p>
            </div>
            <div class="divTableau">
                <p3>Mes équipements</p3>
                <table class="tableau_resultat">
                    <thead>
                        <tr>
                            <th>Catégories</th>
                            <th>Eléments</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for($i = 0; $i <= $nb_category - 1; $i++){ ?><tr>
                            <td><?php $category_name = $JSON[1]['categorie'][$i]; echo $category_name; ?></td>
                            <td>
                                <ul><?php
                                    $nb_of_category = count($tableau_total[$i]);
                                    if ($nb_of_category === 0){
                                        echo "<i>Vous n'avez pas de ".$category_name." à votre disposition</i>";
                                    }elseif ($tableau_total[$i] === 400){
                                        echo "<i>ERREUR 400 : La page n'existe sûrement pas !<br/>Vérifiez si elle existe et/ou si son nom (dans le fichier JSON) est correcte</i>";
                                    }else{
                                        for ($j = 0; $j <= $nb_of_category - 1; $j++){ ?>
                                            <li><?php echo $tableau_total[$i][$j];
                                        }
                                    }
                                    ?></li>
                                </ul>
                            </td>
                        </tr><?php }?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>