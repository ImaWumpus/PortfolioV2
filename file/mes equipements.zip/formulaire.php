<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf8">
        <title>Accueil</title>
        <?php 
            $JSON = file_get_contents("Data.json");
            $JSON = json_decode($JSON, true);
            $CSS = $JSON[0]['fichierDefaultCSS'];
            $resultat = $JSON[0]['fichierResultat'];
        ?>
        <link rel="stylesheet" href=<?php echo $CSS?>>
    </head>
    <nav>
        <a href="https://www.toutatice.fr/portail/">
            <img src="img/toutatice.jpg" alt="toutatice.fr, espace numérique de l'éducation en Bretagne">
        </a>
        <p1>Connexion</p1>
    </nav>
    <section class="login-container">
        <div>
            <header>
                <h2>Identification</h2>
            </header>
            <form action="<?php echo $resultat?>" method="post">
                <input type="text" name="ID" placeholder="Nom d'utilisateur" required="required"/>
                <input type="password" name="password" placeholder="Mot de passe" required="required"/>
                <button type="submit">Connexion</button>
            </form>
        </div>
    </section>
</html>