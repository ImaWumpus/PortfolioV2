


    
<?php           ### On récupère le Session-Token
$ID = "econnat";
$MDP = "St@gi05!";

$JSON = file_get_contents("Data.json");
$JSON = json_decode($JSON, true);
$URL_api = $JSON[0]['URL_api'];
$app_token = $JSON[0]['app_token'];

$curl = curl_init($URL_api.'initSession?app_token='.$app_token.'&login='.$ID.'&password='.$MDP);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);           #permet de ne pas afficher le résultat directement et de la garder en mémoire dans la variable du "curl_exec"
$resultat_initSession = curl_exec($curl);                   #permet d'executer la requete

if ($resultat_initSession === false){               #s'il y a une erreur lors de l'execution/si le serveur ne répond pas
    var_dump(curl_error($curl));                    #affiche l'erreur correspondante
}else {
    if (curl_getinfo($curl, CURLINFO_HTTP_CODE) === 200){                   #si le code http reçu est valide
        $resultat_initSession = json_decode($resultat_initSession, true);   #decode le fichier renvoyé et "true" permet d'avoir un tableau associatif
        $session_token = $resultat_initSession['session_token'];            #enregistre dans la variable le contenu du parametre indiqué du tableau
    }else{
        header('location:formulaire.html');          #s'il y a une erreur tels que de mauvais log et/ou MDP
        exit;                                       #exit pour ne pas faire executer le reste du code
    }
    
}

curl_close($curl);      #permet de fermer la session
?>



<?php       ### On récupère l'ID de l'utilisateur ainsi que son nom/prenom grace à la session_token et l'app_token

$curl = curl_init($URL_api.'getFullSession?app_token='.$app_token.'&session_token='.$session_token);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);           #permet de ne pas afficher le résultat directement et de la garder en mémoire dans la variable du "curl_exec"
$resultat_fullSession = curl_exec($curl);                   #permet d'executer la requete/équivalent à quand on fait "enter" dans le navigateur

if ($resultat_fullSession === false){           #s'il y a une erreur lors de l'execution/si le serveur ne répond pas
    var_dump(curl_error($curl));                #affiche l'erreur correspondante
}else{
    if (curl_getinfo($curl, CURLINFO_HTTP_CODE) === 200){                   #si le code http reçu est valide
        $resultat_fullSession = json_decode($resultat_fullSession, true);   #decode le fichier renvoyé et "true" permet d'avoir un tableau associatif
        $ID_utilisateur = $resultat_fullSession['session']['glpiID'];       #enregistre dans la variable le contenu du parametre indiqué du tableau
        $nom_ID = $resultat_fullSession['session']['glpifriendlyname'];
    }

}

curl_close($curl);      #permet de fermer la session
?>




<?php       ### Liste des équipements mis à disposition

$category = $JSON[1]['category'];
$nb_category = count($category);
$tableau_total = array();

for ($f = 0; $f <= $nb_category - 1; $f++){

    $curl = curl_init($URL_api . $category[$f].'?app_token='.$app_token.'&session_token='.$session_token);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $resultat = curl_exec($curl);      #execute l'URL (equivalent de la touche "enter" quand on fait une recherche)

    if ($resultat === false){          #s'il y a une erreur lors de l'execution/si le serveur ne repond pas
        var_dump(curl_error($curl));
    }else{
        if (curl_getinfo($curl, CURLINFO_HTTP_CODE) === 200){               #s'il n'y a pas d'erreur avec la réponse de l'API
            $resultat = json_decode($resultat, true);     #decode la fichier JSON qui est renvoyé
            $nb_resultat = count($resultat);       #compte le nombre d'entité dans le tableau JSON
            $nom_categorie_utilisateur = array();                #initialisation du tableau
            for ($i = 0; $i <= $nb_resultat-1; $i++){
                if ($resultat[$i]['users_id'] === $ID_utilisateur){                #si l'ID de l'utilisateur du logiciel est le même que celui de la session
                    array_push($nom_categorie_utilisateur, $resultat[$i]['name']);      #ajoute le nom du logiciel dans le tableau
                }
            }
            array_push($tableau_total, $nom_categorie_utilisateur);
        }else{
            if (curl_getinfo($curl, CURLINFO_HTTP_CODE) === 400){
                array_push($tableau_total, curl_getinfo($curl, CURLINFO_HTTP_CODE));
            }
        }
    }

    curl_close($curl);      #permet de fermer la session
}
echo '<pre>';
        var_dump($tableau_total);
    echo '</pre>';

?>

    