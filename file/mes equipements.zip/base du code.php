<?php       ### On regarde si l'utilisateur à des logiciels à sa disposition

$curl = curl_init($URL_api.'software?app_token='.$app_token.'&session_token='.$session_token);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$resultat_software = curl_exec($curl);      #execute l'UR (equivalent de la touche "enter" quand on fait une recherche)

if ($resultat_software === false){          #s'il y a une erreur lors de l'execution/si le serveur ne repond pas
    var_dump(curl_error($curl));
}else{
    if (curl_getinfo($curl, CURLINFO_HTTP_CODE) === 200){               #s'il n'y a pas d'erreur avec la réponse de l'API
        $resultat_software = json_decode($resultat_software, true);     #decode la fichier JSON qui est renvoyé
        $nb_software = count($resultat_software);       #compte le nombre d'entité dans le tableau JSON
        $software_utilisateur = array();                #initialisation du tableau
        for ($i = 0; $i <= $nb_software-1; $i++){
            if ($resultat_software[$i]['users_id'] === $ID_utilisateur){                #si l'ID de l'utilisateur du logiciel est le même que celui de la session
                array_push($software_utilisateur, $resultat_software[$i]['name']);      #ajoute le nom du logiciel dans le tableau
            }
        }
        echo '<pre>';
        var_dump($software_utilisateur);
        echo '</pre>';

    }else{
        echo (curl_getinfo($curl, CURLINFO_HTTP_CODE));         #affiche l'erreur avec l'API
    }
}

curl_close($curl);      #permet de fermer la session

?>