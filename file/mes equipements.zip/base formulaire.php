<form action="test_api.php" method="post">
    <p>Votre Identifiant : <input type="text" name="ID" /></p>
    <p>Votre Mot de passe : <input type="password" name="password" /></p>
    <p><input type="submit" value="Connexion"></p>
</form>